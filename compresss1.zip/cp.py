def compress(string):
    res = ""
    leng = len(s)
    if leng == 0:
        return ""
    if leng == 1:
        return s + "1"
    string = s[0]
    count = 1
    i = 1

    while i < leng:
        if s[i] == s[i - 1]:
            count += 1

        else:
            res = res + str(count)+ s[i - 1]  #store prv data
            count = 1
        i += 1
    res = res + str(count) + s[i - 1]
    return res
if __name__ == '__main__':
    s = input("enter the string:")
print(compress(s))
